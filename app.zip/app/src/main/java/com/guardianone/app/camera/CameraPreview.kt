package com.guardianone.app.camera

import android.view.ViewGroup
import androidx.camera.core.ImageAnalysis
import androidx.camera.view.PreviewView
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.viewinterop.AndroidView

@Composable
fun CameraPreview(
    cameraManager: CameraManager,
    lensFacing: Int,
    motionAnalyzer: ImageAnalysis.Analyzer? = null,
    modifier: Modifier = Modifier,
    onError: (Exception) -> Unit = {}
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current

    val previewView = remember {
        PreviewView(context).apply {
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            scaleType = PreviewView.ScaleType.FILL_CENTER
        }
    }

    DisposableEffect(lensFacing, motionAnalyzer) {
        cameraManager.startCamera(
            context = context,
            lifecycleOwner = lifecycleOwner,
            previewView = previewView,
            motionAnalyzer = motionAnalyzer,
            lensFacing = lensFacing,
            onError = onError
        )

        onDispose {
            cameraManager.stopCamera()
        }
    }

    AndroidView(
        factory = { previewView },
        modifier = modifier
    )
}
