package com.guardianone.app.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.guardianone.app.domain.model.EventModel

@Entity(tableName = "events")
data class EventEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val description: String,
    val timestamp: Long,
    val status: String
)

fun EventEntity.toDomain(): EventModel = EventModel(
    id = id,
    title = title,
    description = description,
    timestamp = timestamp,
    status = status
)

fun EventModel.toEntity(): EventEntity = EventEntity(
    id = id,
    title = title,
    description = description,
    timestamp = timestamp,
    status = status
)
