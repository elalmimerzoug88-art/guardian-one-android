package com.guardianone.app.domain.model

enum class SensitivityPreset(val label: String, val defaultThreshold: Float) {
    LOW("Low (30%)", 30f),
    MEDIUM("Medium (15%)", 15f),
    HIGH("High (5%)", 5f),
    CUSTOM("Custom", 20f)
}

data class MotionSettings(
    val preset: SensitivityPreset = SensitivityPreset.MEDIUM,
    val customThreshold: Float = 15f,
    val autoStopDelaySeconds: Int = 10,
    val autoStartOnBoot: Boolean = false,
    val startServiceOnAppOpen: Boolean = false,
    val stopOnLowBattery: Boolean = true
) {
    val activeThreshold: Float
        get() = when (preset) {
            SensitivityPreset.LOW -> 30f
            SensitivityPreset.MEDIUM -> 15f
            SensitivityPreset.HIGH -> 5f
            SensitivityPreset.CUSTOM -> customThreshold
        }
}
