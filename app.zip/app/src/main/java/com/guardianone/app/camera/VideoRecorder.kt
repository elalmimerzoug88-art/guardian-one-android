package com.guardianone.app.camera

import android.content.ContentValues
import android.content.Context
import android.os.Build
import android.provider.MediaStore
import androidx.camera.video.FileOutputOptions
import androidx.camera.video.MediaStoreOutputOptions
import androidx.camera.video.PendingRecording
import androidx.camera.video.Recorder
import androidx.camera.video.Recording
import androidx.camera.video.VideoCapture
import androidx.camera.video.VideoRecordEvent
import androidx.core.content.ContextCompat
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class VideoRecorder {

    private var activeRecording: Recording? = null
    var isRecording: Boolean = false
        private set

    var currentRecordingStartTimeMs: Long = 0L
        private set

    var peakMotionInCurrentRecording: Float = 0f

    fun startRecording(
        context: Context,
        videoCapture: VideoCapture<Recorder>,
        initialPeakMotion: Float,
        onStarted: () -> Unit,
        onFinished: (filePath: String, fileName: String, durationSeconds: Long, fileSizeBytes: Long) -> Unit,
        onError: (String) -> Unit
    ) {
        if (isRecording) return

        val timeStamp = SimpleDateFormat("yyyy-MM-dd_HH-mm-ss", Locale.US).format(Date())
        val fileName = "GuardianOne_$timeStamp.mp4"

        currentRecordingStartTimeMs = System.currentTimeMillis()
        peakMotionInCurrentRecording = initialPeakMotion

        val pendingRecording: PendingRecording = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val contentValues = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
                put(MediaStore.MediaColumns.RELATIVE_PATH, "Movies/GuardianOne")
            }
            val mediaStoreOptions = MediaStoreOutputOptions.Builder(
                context.contentResolver,
                MediaStore.Video.Media.EXTERNAL_CONTENT_URI
            ).setContentValues(contentValues).build()

            videoCapture.output.prepareRecording(context, mediaStoreOptions)
        } else {
            val moviesDir = File(context.getExternalFilesDir(null), "Movies/GuardianOne")
            if (!moviesDir.exists()) {
                moviesDir.mkdirs()
            }
            val file = File(moviesDir, fileName)
            val fileOptions = FileOutputOptions.Builder(file).build()

            videoCapture.output.prepareRecording(context, fileOptions)
        }

        try {
            activeRecording = pendingRecording
                .start(ContextCompat.getMainExecutor(context)) { event ->
                    when (event) {
                        is VideoRecordEvent.Start -> {
                            isRecording = true
                            onStarted()
                        }
                        is VideoRecordEvent.Finalize -> {
                            isRecording = false
                            activeRecording = null
                            val endTime = System.currentTimeMillis()
                            val duration = ((endTime - currentRecordingStartTimeMs) / 1000).coerceAtLeast(1L)

                            if (!event.hasError()) {
                                val uri = event.outputResults.outputUri
                                val path = uri.path ?: uri.toString()

                                var sizeBytes = 0L
                                try {
                                    if (uri.scheme == "file") {
                                        val f = File(uri.path!!)
                                        sizeBytes = if (f.exists()) f.length() else 0L
                                    } else {
                                        context.contentResolver.openFileDescriptor(uri, "r")?.use { pfd ->
                                            sizeBytes = pfd.statSize
                                        }
                                    }
                                } catch (e: Exception) {
                                    sizeBytes = 1024L * 1024L * duration
                                }

                                if (sizeBytes <= 0L) {
                                    sizeBytes = 1024L * 512L * duration
                                }

                                onFinished(path, fileName, duration, sizeBytes)
                            } else {
                                onError("Recording error: ${event.error}")
                            }
                        }
                    }
                }
        } catch (e: Exception) {
            isRecording = false
            activeRecording = null
            onError(e.localizedMessage ?: "Failed to start Video Recording")
        }
    }

    fun stopRecording() {
        if (isRecording && activeRecording != null) {
            try {
                activeRecording?.stop()
            } catch (e: Exception) {
                e.printStackTrace()
            } finally {
                activeRecording = null
                isRecording = false
            }
        }
    }
}
