package com.guardianone.app.domain.usecase

import com.guardianone.app.domain.model.EventModel
import com.guardianone.app.domain.repository.GuardianRepository
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject

class GetEventsUseCase @Inject constructor(
    private val repository: GuardianRepository
) {
    operator fun invoke(): Flow<List<EventModel>> {
        return repository.getAllEvents()
    }
}
